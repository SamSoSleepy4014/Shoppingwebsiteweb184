import { useState } from 'react';
import { ThemeProvider } from './components/ThemeProvider';
import { Sidebar } from './components/Sidebar';
import { HomePage } from './components/HomePage';
import { ProductPage } from './components/ProductPage';
import { Toaster } from './components/ui/sonner';
import { Menu } from 'lucide-react';
import { Button } from './components/ui/button';
import backgroundImage from 'figma:asset/0e46fb7a05178e5fa1e44e845b1601b95d2f0772.png';

type Page = 'home' | 'addon' | 'map' | 'mcui';

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  return (
    <ThemeProvider>
      <div 
        className="flex h-screen bg-gray-50 dark:bg-gray-900 relative"
        style={{
          backgroundImage: `url(${backgroundImage})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundAttachment: 'fixed',
        }}
      >
        {/* Overlay for better readability */}
        <div className="absolute inset-0 bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm"></div>
        
        {/* Content */}
        <div className="relative z-10 flex w-full h-full">
          {/* Hamburger Menu Button */}
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="fixed top-4 left-4 z-50 transition-all duration-200 hover:scale-110 active:scale-95"
          >
            <Menu className="h-6 w-6" />
          </Button>

          <Sidebar 
            currentPage={currentPage} 
            onPageChange={setCurrentPage}
            isOpen={isSidebarOpen}
            onToggle={() => setIsSidebarOpen(!isSidebarOpen)}
          />
          <main className="flex-1 overflow-auto pt-16">
            {currentPage === 'home' && <HomePage />}
            {currentPage === 'addon' && <ProductPage type="addon" />}
            {currentPage === 'map' && <ProductPage type="map" />}
            {currentPage === 'mcui' && <ProductPage type="mcui" />}
          </main>
        </div>
      </div>
      <Toaster />
    </ThemeProvider>
  );
}
