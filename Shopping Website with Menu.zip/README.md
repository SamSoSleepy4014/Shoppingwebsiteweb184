
  # Shopping Website with Menu

  This is a code bundle for Shopping Website with Menu. The original project is available at https://www.figma.com/design/eJAuJRziUByY00606ZXBta/Shopping-Website-with-Menu.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  